# لوحة الإدارة - أطباء العراق v5

## ما تمت إضافته
- لوحة إدارة.
- قائمة طلبات الأطباء المعلقة.
- موافقة أو رفض الطبيب.
- قائمة الأطباء المقبولين.
- تفعيل/إيقاف الاشتراك بشكل إداري.
- الطبيب لا يظهر للمرضى إلا إذا كان APPROVED واشتراكه فعال.

## قبل الإطلاق
هذا الإصدار يستخدم بيانات محلية للتجربة.
للتشغيل الحقيقي يجب ربط:
- Firebase Authentication
- Cloud Firestore
- صلاحية Admin Role / custom claims
- Google Maps

## نموذج Firestore
doctors/{doctorId}
{
  name,
  specialty,
  province,
  address,
  phone,
  latitude,
  longitude,
  status: "PENDING|APPROVED|REJECTED",
  subscribed: true/false,
  subscriptionExpiry: timestamp
}

adminUsers/{uid}
{
  role: "admin"
}

## ملاحظة أمنية
لا تعتمد على إخفاء زر الإدارة فقط. في النسخة الحقيقية يجب أن تكون صلاحيات Firestore نفسها تمنع الطبيب العادي من تعديل حالة التحقق أو الاشتراك.
