# ربط أطباء العراق بـ Firebase

1. أنشئ مشروعاً في Firebase Console.
2. أضف تطبيق Android باسم الحزمة: `com.example.atbaaaliraq`
3. نزّل `google-services.json` وضعه داخل مجلد `app/`.
4. فعّل Authentication > Anonymous مؤقتاً لتجربة قاعدة البيانات، ثم ننتقل لاحقاً لتسجيل الطبيب الحقيقي.
5. أنشئ Cloud Firestore Database.
6. انسخ محتوى `firestore.rules` إلى Firestore Rules ثم Publish.
7. ابنِ التطبيق.

ملاحظة: ملف `google-services.json` يحتوي معرّفات مشروع غير سرية بحسب توثيق Firebase، لكن لا تضع أي مفاتيح سرية للدفع داخل التطبيق.
