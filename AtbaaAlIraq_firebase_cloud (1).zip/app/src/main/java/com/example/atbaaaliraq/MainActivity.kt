package com.example.atbaaaliraq

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private enum class DoctorStatus { PENDING, APPROVED, REJECTED }
private data class Doctor(
    val id: String,
    val name: String,
    val specialty: String,
    val province: String,
    val address: String,
    val phone: String,
    val latitude: Double,
    val longitude: Double,
    val status: DoctorStatus,
    val subscribed: Boolean
)

private val doctors = mutableStateListOf(
    Doctor("1", "د. أحمد محمد", "باطنية", "النجف", "شارع الروان", "07700000001", 32.0259, 44.3463, DoctorStatus.APPROVED, true),
    Doctor("2", "د. علي حسين", "قلب وشرايين", "بغداد", "المنصور", "07700000002", 33.3152, 44.3661, DoctorStatus.APPROVED, true),
    Doctor("3", "د. سارة كريم", "أطفال", "كربلاء", "حي الحسين", "07700000003", 32.6160, 44.0249, DoctorStatus.PENDING, false)
)

private fun saveDoctors(context: Context) {
    val prefs = context.getSharedPreferences("atbaa_iraq", Context.MODE_PRIVATE)
    val data = doctors.joinToString("\n") { listOf(it.id,it.name,it.specialty,it.province,it.address,it.phone,it.latitude,it.longitude,it.status.name,it.subscribed).joinToString("|") }
    prefs.edit().putString("doctors", data).apply()
}

private fun loadDoctors(context: Context) {
    val prefs = context.getSharedPreferences("atbaa_iraq", Context.MODE_PRIVATE)
    val raw = prefs.getString("doctors", null) ?: return
    val loaded = raw.lines().mapNotNull { line ->
        val x = line.split("|")
        if (x.size < 10) null else runCatching { Doctor(x[0],x[1],x[2],x[3],x[4],x[5],x[6].toDouble(),x[7].toDouble(),DoctorStatus.valueOf(x[8]),x[9].toBoolean()) }.getOrNull()
    }
    if (loaded.isNotEmpty()) { doctors.clear(); doctors.addAll(loaded) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadDoctors(this)
        FirebaseRepository.signInAnonymously { ok ->
            if (ok) setContent { CloudApp() } else setContent { App() }
        }
    }
}

@Composable
private fun CloudApp() {
    var cloudDoctors by remember { mutableStateOf<List<DoctorCloud>>(emptyList()) }
    var selected by remember { mutableStateOf<DoctorCloud?>(null) }
    var screen by remember { mutableStateOf("home") }
    DisposableEffect(Unit) {
        val listener = FirebaseRepository.listenApprovedDoctors({ cloudDoctors = it }, {})
        onDispose { listener.remove() }
    }
    MaterialTheme {
        when (screen) {
            "home" -> CloudHome(cloudDoctors, { selected = it; screen = "details" }, { screen = "register" })
            "details" -> selected?.let { CloudDetails(it) { screen = "home" } }
            "register" -> CloudRegister { screen = "home" }
        }
    }
}

@Composable
private fun CloudHome(list: List<DoctorCloud>, onDoctor: (DoctorCloud) -> Unit, onRegister: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var province by remember { mutableStateOf("") }
    val filtered = list.filter { it.subscribed && (q.isBlank() || it.name.contains(q, true) || it.specialty.contains(q, true)) && (province.isBlank() || it.province.contains(province, true)) }
    Scaffold(topBar = { TopAppBar(title = { Text("🩺 أطباء العراق") }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("الأطباء من قاعدة البيانات السحابية", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("الاسم أو الاختصاص") })
                OutlinedTextField(province, { province = it }, Modifier.fillMaxWidth(), label = { Text("المحافظة") })
                OutlinedButton(onClick = onRegister, Modifier.fillMaxWidth()) { Text("تسجيل طبيب") }
            }
            items(filtered) { d -> Card(onClick = { onDoctor(d) }, Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(d.name, style = MaterialTheme.typography.titleLarge); Text(d.specialty); Text("📍 ${d.province} - ${d.address}") } } }
            item { if (filtered.isEmpty()) Text("لا توجد نتائج حالياً.") }
        }
    }
}

@Composable
private fun CloudDetails(d: DoctorCloud, onBack: () -> Unit) {
    val context = LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text("ملف الطبيب") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(d.name, style = MaterialTheme.typography.headlineMedium); Text(d.specialty); Text(d.province); Text(d.address); Text(d.phone)
            Button(onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${d.phone}"))) }, Modifier.fillMaxWidth()) { Text("📞 اتصال") }
            Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${d.latitude},${d.longitude}?q=${d.latitude},${d.longitude}(${Uri.encode(d.name)})"))) }, Modifier.fillMaxWidth()) { Text("🗺️ الموقع") }
        }
    }
}

@Composable
private fun CloudRegister(onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }; var specialty by remember { mutableStateOf("") }; var province by remember { mutableStateOf("") }; var address by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("تسجيل طبيب") }, navigationIcon = { TextButton(onClick = onDone) { Text("رجوع") } }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("اسم الطبيب" to name, "الاختصاص" to specialty, "المحافظة" to province, "عنوان العيادة" to address, "رقم الهاتف" to phone).forEach { (label, value) -> OutlinedTextField(value, { v -> when(label) { "اسم الطبيب" -> name=v; "الاختصاص" -> specialty=v; "المحافظة" -> province=v; "عنوان العيادة" -> address=v; "رقم الهاتف" -> phone=v } }, Modifier.fillMaxWidth(), label={Text(label)}) }
            Button(onClick = { FirebaseRepository.submitDoctor(DoctorCloud(name=name,specialty=specialty,province=province,address=address,phone=phone), { ok,_ -> if(ok) onDone() }) }, Modifier.fillMaxWidth(), enabled=name.isNotBlank()&&specialty.isNotBlank()&&phone.isNotBlank()) { Text("إرسال الطلب") }
        }
    }
}


@Composable
private fun App() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf<Doctor?>(null) }
    MaterialTheme {
        when (screen) {
            "home" -> Home(
                onDoctor = { selected = it; screen = "details" },
                onDoctorLogin = { screen = "doctorLogin" },
                onRegister = { screen = "register" },
                onAdmin = { screen = "admin" }
            )
            "details" -> selected?.let { Details(it) { screen = "home" } }
            "doctorLogin" -> DoctorLogin({ screen = "home" }) { screen = "doctorPanel" }
            "doctorPanel" -> DoctorPanel({ screen = "home" }) { screen = "subscription" }
            "subscription" -> Subscription { screen = "doctorPanel" }
            "register" -> RegisterDoctor { screen = "home" }
            "admin" -> AdminPanel { screen = "home" }
        }
    }
}

@Composable
private fun Home(
    onDoctor: (Doctor) -> Unit,
    onDoctorLogin: () -> Unit,
    onRegister: () -> Unit,
    onAdmin: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    var province by remember { mutableStateOf("") }
    val list = doctors.filter { it.status == DoctorStatus.APPROVED && it.subscribed }.filter {
        (q.isBlank() || it.name.contains(q, true) || it.specialty.contains(q, true)) &&
            (province.isBlank() || it.province.contains(province, true))
    }
    Scaffold(topBar = { TopAppBar(title = { Text("🩺 أطباء العراق") }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("ابحث عن طبيب", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("الاسم أو الاختصاص") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(province, { province = it }, Modifier.fillMaxWidth(), label = { Text("المحافظة") })
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onDoctorLogin, modifier = Modifier.weight(1f)) { Text("دخول الطبيب") }
                    OutlinedButton(onClick = onRegister, modifier = Modifier.weight(1f)) { Text("تسجيل طبيب") }
                }
                TextButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) { Text("لوحة الإدارة التجريبية") }
            }
            items(list) { d ->
                Card(onClick = { onDoctor(d) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleLarge)
                        Text(d.specialty)
                        Text("📍 ${d.province} - ${d.address}")
                        Text("✓ طبيب موثّق")
                    }
                }
            }
            item { if (list.isEmpty()) Text("لا توجد نتائج حالياً.") }
        }
    }
}

@Composable
private fun Details(d: Doctor, onBack: () -> Unit) {
    val context = LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text("ملف الطبيب") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(d.name, style = MaterialTheme.typography.headlineMedium)
            Text("✓ طبيب موثّق")
            Text("الاختصاص: ${d.specialty}")
            Text("المحافظة: ${d.province}")
            Text("العنوان: ${d.address}")
            Text("الهاتف: ${d.phone}")
            Spacer(Modifier.height(6.dp))
            Button(onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${d.phone}"))) }, modifier = Modifier.fillMaxWidth()) { Text("📞 اتصال بالطبيب") }
            Button(onClick = {
                val uri = Uri.parse("geo:${d.latitude},${d.longitude}?q=${d.latitude},${d.longitude}(${Uri.encode(d.name)})")
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            }, modifier = Modifier.fillMaxWidth()) { Text("🗺️ فتح موقع العيادة") }
        }
    }
}

@Composable
private fun DoctorLogin(onBack: () -> Unit, onSuccess: () -> Unit) {
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("دخول الطبيب") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("حساب الطبيب", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text("رقم الهاتف") })
            OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("كلمة المرور") })
            Button(onClick = onSuccess, Modifier.fillMaxWidth(), enabled = phone.isNotBlank() && password.isNotBlank()) { Text("دخول") }
            Text("هذه نسخة تطوير. التحقق الحقيقي سيكون عبر Firebase Authentication.")
        }
    }
}

@Composable
private fun DoctorPanel(onHome: () -> Unit, onSubscribe: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("لوحة الطبيب") }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("إدارة ملفك الطبي", style = MaterialTheme.typography.headlineSmall)
            Text("عدّل بيانات العيادة، الموقع، الهاتف والاختصاص من الحساب الحقيقي بعد ربط قاعدة البيانات.")
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("الاشتراك الشهري"); Text("5,000 دينار عراقي"); Text("الحالة: غير مربوطة بالدفع الحقيقي بعد") } }
            Button(onClick = onSubscribe, Modifier.fillMaxWidth()) { Text("إدارة الاشتراك") }
            OutlinedButton(onClick = onHome, Modifier.fillMaxWidth()) { Text("العودة للتطبيق") }
        }
    }
}

@Composable
private fun Subscription(onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("الاشتراك") }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("اشتراك الطبيب", style = MaterialTheme.typography.headlineSmall)
            Text("5,000 د.ع / شهر")
            Text("سيتم ربط بوابة الدفع الحقيقية بالخادم، ولن يتم وضع أي مفتاح سري داخل التطبيق.")
            Button(onClick = {}, Modifier.fillMaxWidth()) { Text("الدفع - سيُفعّل بعد الربط") }
        }
    }
}

@Composable
private fun RegisterDoctor(onDone: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }
    var province by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("تسجيل طبيب") }, navigationIcon = { TextButton(onClick = onDone) { Text("رجوع") } }) }) { p ->
        Column(Modifier.padding(p).padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("اسم الطبيب" to name, "الاختصاص" to specialty, "المحافظة" to province, "عنوان العيادة" to address, "رقم الهاتف" to phone).forEach { (label, value) ->
                OutlinedTextField(value, { v -> when (label) { "اسم الطبيب" -> name = v; "الاختصاص" -> specialty = v; "المحافظة" -> province = v; "عنوان العيادة" -> address = v; "رقم الهاتف" -> phone = v } }, Modifier.fillMaxWidth(), label = { Text(label) })
            }
            Button(onClick = {
                doctors.add(Doctor(System.currentTimeMillis().toString(), name, specialty, province, address, phone, 0.0, 0.0, DoctorStatus.PENDING, false))
                saveDoctors(context)
                onDone()
            }, Modifier.fillMaxWidth(), enabled = name.isNotBlank() && specialty.isNotBlank() && phone.isNotBlank()) { Text("إرسال طلب التسجيل") }
        }
    }
}

@Composable
private fun AdminPanel(onHome: () -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableStateOf(0) }
    val pending = doctors.filter { it.status == DoctorStatus.PENDING }
    val approved = doctors.filter { it.status == DoctorStatus.APPROVED }
    Scaffold(topBar = { TopAppBar(title = { Text("👑 لوحة الإدارة") }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("طلبات معلقة: ${pending.size}"); Text("أطباء مقبولون: ${approved.size}"); Text("مشتركون فعالون: ${doctors.count { it.status == DoctorStatus.APPROVED && it.subscribed }}") }
            items(pending) { d ->
                AdminCard(d, onApprove = { changeStatus(d.id, DoctorStatus.APPROVED); saveDoctors(context); refresh++ }, onReject = { changeStatus(d.id, DoctorStatus.REJECTED); saveDoctors(context); refresh++ })
            }
            items(approved) { d ->
                AdminCard(d, onApprove = { toggleSubscription(d.id); saveDoctors(context); refresh++ }, onReject = { changeStatus(d.id, DoctorStatus.REJECTED); saveDoctors(context); refresh++ })
            }
            item { Button(onClick = onHome, Modifier.fillMaxWidth()) { Text("عرض التطبيق") } }
        }
    }
}

@Composable
private fun AdminCard(d: Doctor, onApprove: () -> Unit, onReject: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(d.name, style = MaterialTheme.typography.titleLarge)
            Text("${d.specialty} - ${d.province}")
            Text(d.phone)
            Text(if (d.subscribed) "💳 الاشتراك فعال" else "💳 غير مشترك")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = onApprove) { Text(if (d.status == DoctorStatus.PENDING) "موافقة" else "تبديل الاشتراك") }
                OutlinedButton(onClick = onReject) { Text(if (d.status == DoctorStatus.PENDING) "رفض" else "إيقاف") }
            }
        }
    }
}

private fun changeStatus(id: String, status: DoctorStatus) {
    val i = doctors.indexOfFirst { it.id == id }
    if (i >= 0) doctors[i] = doctors[i].copy(status = status)
}
private fun toggleSubscription(id: String) {
    val i = doctors.indexOfFirst { it.id == id }
    if (i >= 0) doctors[i] = doctors[i].copy(subscribed = !doctors[i].subscribed)
}
