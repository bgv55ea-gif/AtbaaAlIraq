package com.example.atbaaaliraq

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

object FirebaseRepository {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    fun signInAnonymously(onDone: (Boolean) -> Unit) {
        if (auth.currentUser != null) { onDone(true); return }
        auth.signInAnonymously().addOnCompleteListener { onDone(it.isSuccessful) }
    }

    fun listenApprovedDoctors(onDoctors: (List<DoctorCloud>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("doctors").whereEqualTo("status", "APPROVED").addSnapshotListener { snap, e ->
            if (e != null) { onError(e); return@addSnapshotListener }
            val list = snap?.documents.orEmpty().mapNotNull { it.toObject(DoctorCloud::class.java)?.copy(id = it.id) }
            onDoctors(list)
        }
    }

    fun submitDoctor(d: DoctorCloud, onDone: (Boolean, Exception?) -> Unit) {
        val data = hashMapOf(
            "name" to d.name, "specialty" to d.specialty, "province" to d.province,
            "address" to d.address, "phone" to d.phone, "latitude" to d.latitude,
            "longitude" to d.longitude, "status" to "PENDING", "subscribed" to false,
            "ownerUid" to auth.currentUser?.uid
        )
        db.collection("doctors").add(data).addOnCompleteListener { onDone(it.isSuccessful, it.exception) }
    }

    fun updateDoctor(id: String, status: String? = null, subscribed: Boolean? = null, onDone: (Boolean) -> Unit) {
        val data = mutableMapOf<String, Any>()
        if (status != null) data["status"] = status
        if (subscribed != null) data["subscribed"] = subscribed
        db.collection("doctors").document(id).update(data).addOnCompleteListener { onDone(it.isSuccessful) }
    }
}

data class DoctorCloud(
    var id: String = "",
    var name: String = "",
    var specialty: String = "",
    var province: String = "",
    var address: String = "",
    var phone: String = "",
    var latitude: Double = 0.0,
    var longitude: Double = 0.0,
    var status: String = "PENDING",
    var subscribed: Boolean = false,
    var ownerUid: String? = null
)
