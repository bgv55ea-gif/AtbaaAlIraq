plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
 id("org.jetbrains.kotlin.plugin.compose")
 id("com.google.gms.google-services")
}
android {
 namespace="com.example.atbaaaliraq"
 compileSdk=35
 defaultConfig {
  applicationId="com.example.atbaaaliraq"
  minSdk=24
  targetSdk=35
  versionCode=5
  versionName="5.0"
 }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.activity:activity-compose:1.10.0")
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material3:material3")
 debugImplementation("androidx.compose.ui:ui-tooling")
 implementation(platform("com.google.firebase:firebase-bom:34.19.0"))
 implementation("com.google.firebase:firebase-auth")
 implementation("com.google.firebase:firebase-firestore")
}
